set TOP_MODULE "top"

# 1. Setup Library Search Paths and Load Library
set_db init_lib_search_path /home/install/FOUNDRY/digital/90nm/dig/lib
read_libs slow.lib

# 2. Read Synthesized Netlist & Elaborate
read_netlist output/netlist/${TOP_MODULE}_opt.v
elaborate $TOP_MODULE

# 3. Read SDC Constraints
read_sdc constraints/top.sdc

# 4. Create Output Folder Structure
file mkdir output/reports

# 5. Batch VCD Processing & Power Reporting
set VCD_DIR "vcd"

puts "--------------------------------------------------------------------"
puts "INFO: Starting Batch VCD Power Analysis Flow..."
puts "--------------------------------------------------------------------"

foreach vcd_file [glob -nocomplain "$VCD_DIR/*.vcd"] {
    set mod_name [file rootname [file tail $vcd_file]]
    
    puts "\nProcessing Module: $mod_name"
    puts "--> Reading VCD: $vcd_file"

    if {[catch {read_vcd $vcd_file} err]} {
        puts "ERROR: Failed to annotate VCD for $mod_name. Reason: $err"
        continue
    }

    set report_file "output/reports/${mod_name}_vcd_power.rpt"
    
    if {[catch {report_power > $report_file} err]} {
        puts "ERROR: Power reporting failed for $mod_name. Reason: $err"
        continue
    }
    
    puts "--> Successfully generated: $report_file"
}

puts "--- VCD Power Analysis completed successfully! Check output/reports/ directory ---"
exit
