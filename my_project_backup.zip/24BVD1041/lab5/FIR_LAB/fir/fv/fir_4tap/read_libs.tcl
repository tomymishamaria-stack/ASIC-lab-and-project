add_search_path /home/install/FOUNDRY/digital/180nm/dig/lib -library -both
read_library -liberty -both \
    /home/install/FOUNDRY/digital/180nm/dig/lib/slow.lib \
    /home/install/FOUNDRY/digital/180nm/dig/lib/slow.lib

